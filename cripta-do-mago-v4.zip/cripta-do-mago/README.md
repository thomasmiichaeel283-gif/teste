# Cripta do Mago

Roguelike por turnos em HTML5/canvas. Desça 3 andares, limpe cada sala e derrote o Lorde Demônio.

## Como jogar
Abra `index.html` com duplo clique (não precisa de servidor nem de internet).
Setas/WASD ou toque: mover e atacar · Espaço: esperar · M: música.

Opcional, servidor local: `npx serve .`

## Estrutura
```
index.html        esqueleto
css/style.css     estilo + @font-face
js/config.js      constantes, inimigos, níveis, recompensas, balanceamento  <- edite aqui
js/manifest.js    lista de assets
js/assets.js      carregamento de imagens/áudio
js/input.js       teclado e toque
js/game.js        estado e regras (turnos, combate, IA)
js/render.js      todo o desenho
js/main.js        bootstrap e loop
assets/           sprites, fx, sfx, music, fonts (arquivos individuais)
```
Os scripts são clássicos (não ES modules) de propósito: módulos são bloqueados em `file://`.
A ordem dos `<script>` no `index.html` importa.

## Adicionar conteúdo
- Novo inimigo: entrada em `ENEMY_TYPES` + sprite em `assets/sprites/` + nome em `js/manifest.js`.
- Novo nível: novo objeto em `LEVELS` (`js/config.js`).
- Nova recompensa: entrada em `UPGRADES`.
