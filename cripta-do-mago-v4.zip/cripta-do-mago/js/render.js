// Todo o desenho no canvas. Não altera regras de jogo (só contadores visuais: frame, shake, efeitos).
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const { TILE, MAP_W, MAP_H, VIEW_W, VIEW_H } = CONFIG;

function setupCanvas() {
  canvas.width = VIEW_W * CONFIG.ZOOM;
  canvas.height = VIEW_H * CONFIG.ZOOM;
  ctx.scale(CONFIG.ZOOM, CONFIG.ZOOM);
  ctx.imageSmoothingEnabled = false;
}

function drawText(text, x, y, size, color, align) {
  ctx.font = size + 'px "' + CONFIG.FONT + '"';
  ctx.fillStyle = color;
  ctx.textAlign = align || 'left';
  ctx.fillText(text, x, y);
}

// Sprite alinhado ao centro horizontal e ao pé do tile.
function drawSprite(name, x, y) {
  const img = IMAGES[name];
  ctx.drawImage(img, x * TILE + (TILE - img.width) / 2, y * TILE + TILE - img.height);
}

const tileHash = (x, y) => (x * 7 + y * 13) % 11;
function floorSprite(x, y) {
  const h = tileHash(x, y);
  return h === 0 ? 'floor_stain_1' : h === 6 ? 'floor_stain_2' : 'floor_plain';
}

function drawLoading(progress, errorMsg) {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
  if (errorMsg) { ctx.fillStyle = '#f55'; ctx.fillText(errorMsg, VIEW_W / 2, VIEW_H / 2); return; }
  ctx.fillStyle = '#fff'; ctx.fillText('Carregando...', VIEW_W / 2, VIEW_H / 2 - 8);
  ctx.strokeStyle = '#ffd24a'; ctx.strokeRect(VIEW_W / 2 - 50.5, VIEW_H / 2 + 0.5, 100, 6);
  ctx.fillStyle = '#ffd24a'; ctx.fillRect(VIEW_W / 2 - 50, VIEW_H / 2 + 1, 100 * progress, 5);
}

function drawMenuScreen() {
  const { state, turn, best, player } = game;
  for (let y = 0; y < MAP_H; y++) for (let x = 0; x < MAP_W; x++) ctx.drawImage(IMAGES[floorSprite(x, y)], x * TILE, y * TILE);
  ctx.fillStyle = '#000b'; ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  const win = state === 'win', over = state === 'over';
  ctx.drawImage(IMAGES[over ? 'monster_skelet' : 'hero_basic'], 60, 28, 64, 64);
  if (!win) ctx.drawImage(IMAGES.monster_demon, 190, 6, 96, 96);
  drawText(win ? 'VITORIA!' : over ? 'VOCE CAIU' : 'CRIPTA DO MAGO', VIEW_W / 2, 118, 20,
    win ? '#6cff8a' : over ? '#ff5555' : '#ffd24a', 'center');
  const lines = win ? ['O Lorde Demonio caiu e o selo foi quebrado.', 'O reino esta salvo. Fim!']
    : over ? ['A cripta venceu desta vez.', 'Tente de novo e use bem as pocoes.']
    : ['O Mago selou a cripta e invocou um demonio.', 'Desca 3 andares, limpe cada sala', 'e derrote o Lorde Demonio.',
       'Setas/WASD ou toque: mover e atacar.', 'Espaco: esperar.  M: musica.'];
  if (state !== 'title') lines.push('Turnos: ' + turn + '   Inimigos: ' + player.kills);
  if (best && state !== 'over') lines.push('Recorde: ' + best + ' turnos');
  lines.forEach((s, i) => drawText(s, VIEW_W / 2, 142 + i * 12, 8, '#fff', 'center'));
  drawText(win ? 'ENTER: voltar ao inicio' : 'ENTER: ' + (over ? 'tentar de novo' : 'comecar'), VIEW_W / 2, 212, 9, '#ffd24a', 'center');
}

function drawWorld() {
  const { grid, enemies, player: p, frame } = game;
  for (let y = 0; y < MAP_H; y++) for (let x = 0; x < MAP_W; x++) {
    const ch = grid[y][x], h = tileHash(x, y);
    if (ch === '#') {
      ctx.drawImage(IMAGES.wall_center, x * TILE, y * TILE);
      if (y < MAP_H - 1 && grid[y + 1][x] !== '#') {   // decoração só em paredes viradas ao salão
        if (h === 3) drawSprite(frame >> 3 & 1 ? 'torch_1' : 'torch_2', x, y);
        else if (h === 7) ctx.drawImage(IMAGES.wall_flag_red, x * TILE, y * TILE);
      }
    } else ctx.drawImage(IMAGES[floorSprite(x, y)], x * TILE, y * TILE);
    if (ch === 'D') ctx.drawImage(IMAGES.door_closed, x * TILE, y * TILE, TILE, TILE);
    if (ch === '>') ctx.drawImage(IMAGES.Floor_ladder, x * TILE, y * TILE);
    if (ch === 'h') ctx.drawImage(IMAGES.flask_big_red, x * TILE + 3, y * TILE + 3);
    if (ch === 'w') ctx.drawImage(IMAGES.weapon_sword_steel, x * TILE + 4, y * TILE, 8, 16);
    if (ch === 'd') ctx.drawImage(IMAGES.item_armor, x * TILE, y * TILE, TILE, TILE);
  }

  // Zona de perigo do boss
  for (const e of enemies) if (e.warn) {
    ctx.fillStyle = 'rgba(255,40,40,' + (0.25 + 0.15 * Math.sin(frame / 4)) + ')';
    for (let y = 0; y < MAP_H; y++) for (let x = 0; x < MAP_W; x++)
      if (Math.abs(x - e.x) + Math.abs(y - e.y) <= BALANCE.BOSS_BLAST_RADIUS && grid[y][x] !== '#') ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
  }

  const bob = frame >> 5 & 1;
  for (const e of enemies) {
    ctx.save(); ctx.translate(0, -bob); drawSprite(e.sprite, e.x, e.y); ctx.restore();
    if (e.hp < e.maxHp) {   // barra de vida
      const bw = e.boss ? 30 : 14, bx = e.x * TILE + (e.boss ? -7 : 1), by = e.y * TILE - (e.boss ? 16 : 2);
      ctx.fillStyle = '#400'; ctx.fillRect(bx, by, bw, 2);
      ctx.fillStyle = '#e33'; ctx.fillRect(bx, by, bw * e.hp / e.maxHp, 2);
    }
  }
  drawSprite(p.def > 0 ? 'npc_knight_blue' : 'hero_basic', p.x, p.y - bob * 0.5 / TILE);
  if (p.atk > 3) ctx.drawImage(IMAGES.weapon_sword_steel, p.x * TILE + 10, p.y * TILE + 3, 5, 10);

  ctx.globalCompositeOperation = 'lighter';
  game.sparks = game.sparks.filter(f => --f.t > 0);
  for (const f of game.sparks) { ctx.globalAlpha = f.t / f.max; ctx.drawImage(FX_IMAGES[f.kind], f.x - f.size / 2, f.y - f.size / 2, f.size, f.size); }
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  game.popups = game.popups.filter(f => --f.t > 0);
  game.popups.forEach(f => drawText(f.text, f.x, f.y - (50 - f.t) / 3, 8, f.color));
}

function drawUpgradePicker() {
  ctx.fillStyle = '#000c'; ctx.fillRect(0, 0, VIEW_W, MAP_H * TILE);
  drawText('ESCOLHA UMA RECOMPENSA', VIEW_W / 2, 34, 12, '#ffd24a', 'center');
  game.options.forEach((o, i) => {
    const x = 8 + i * 104;
    ctx.fillStyle = '#2a2438'; ctx.fillRect(x, 56, 96, 96);
    ctx.strokeStyle = '#ffd24a'; ctx.strokeRect(x + 0.5, 56.5, 95, 95);
    drawText(i + 1 + '', x + 48, 82, 16, '#ffd24a', 'center');
    o.name.split(': ').forEach((t, j) => drawText(t, x + 48, 112 + j * 16, 7, '#fff', 'center'));
  });
}

function drawHud() {
  const { player: p, levelIndex, enemies, message } = game, y0 = MAP_H * TILE;
  ctx.fillStyle = '#000'; ctx.fillRect(0, y0, VIEW_W, CONFIG.HUD_ROWS * TILE);
  drawText('ANDAR ' + (levelIndex + 1) + '/' + LEVELS.length + '  ' + LEVELS[levelIndex].name, 4, y0 + 10, 8, '#ffd24a');
  drawText('VIDA ' + p.hp + '/' + p.maxHp, 4, y0 + 22, 8, '#ff7777');
  drawText('ATAQUE ' + p.atk, 80, y0 + 22, 8, '#fff');
  drawText('DEFESA ' + p.def, 140, y0 + 22, 8, '#fff');
  drawText('INIMIGOS ' + enemies.length, 230, y0 + 22, 8, '#aaa');
  drawText(message, 4, y0 + 35, 7, '#ccc');
}

function render() {
  game.frame++;
  ctx.fillStyle = '#14101a'; ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  if (game.state === 'title' || game.state === 'win' || game.state === 'over') { drawMenuScreen(); return; }

  ctx.save();
  if (game.shake > 0) { ctx.translate((Math.random() - 0.5) * game.shake / 2, (Math.random() - 0.5) * game.shake / 2); game.shake--; }
  drawWorld();
  ctx.restore();
  if (game.state === 'pick') drawUpgradePicker();
  drawHud();
}
