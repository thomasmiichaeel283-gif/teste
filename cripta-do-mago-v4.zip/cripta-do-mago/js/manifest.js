// Lista de assets (dados). Em .js e não .json porque fetch() não funciona em file://.
const MANIFEST = {
  sprites: [
    'hero_basic', 'npc_knight_blue',
    'monster_bat', 'monster_skelet', 'monster_zombie_green', 'monster_chort',
    'monster_imp', 'monster_elemental_goo_small', 'monster_demon',
    'wall_center', 'wall_flag_red', 'floor_plain', 'floor_stain_1', 'floor_stain_2',
    'torch_1', 'torch_2', 'door_closed', 'Floor_ladder',
    'flask_big_red', 'weapon_sword_steel', 'item_armor',
  ],
  fx: ['slash_01', 'slash_02', 'slash_03', 'slash_04', 'scratch_01', 'magic_01', 'magic_03'],
  // nome do som -> quantidade de variações (arquivos nome_1.ogg, nome_2.ogg ...)
  sfx: { step: 6, hit: 5, coin: 2, door: 2, hurt: 4, die: 3, ok: 1, no: 1, win: 1, lose: 1 },
  music: 6,  // music/bgm_1.ogg ... bgm_6.ogg
};
