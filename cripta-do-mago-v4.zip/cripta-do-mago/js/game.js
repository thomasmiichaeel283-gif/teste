// Estado e regras do jogo (sem desenho). Turnos: cada ação do jogador dispara o turno dos inimigos.
const game = {
  state: 'title',      // title | play | pick | over | win
  levelIndex: 0,
  grid: [],            // matriz de caracteres do mapa atual
  enemies: [],
  player: null,
  message: '',
  popups: [],          // textos flutuantes (dano/cura)
  sparks: [],          // efeitos visuais
  turn: 0,
  frame: 0,
  shake: 0,
  options: [],         // recompensas oferecidas
  best: null,
};

try { game.best = +localStorage.getItem(CONFIG.BEST_KEY) || null; } catch (e) {}

const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const isWall = ch => ch === '#' || ch === 'D';

const enemyAt = (x, y) => game.enemies.find(e => e.x === x && e.y === y);
const isFree = (x, y) =>
  !isWall(game.grid[y][x]) && !enemyAt(x, y) && !(game.player.x === x && game.player.y === y);

function addPopup(x, y, text, color) {
  game.popups.push({ x: x * CONFIG.TILE + 4, y: y * CONFIG.TILE, t: 50, text, color });
}
function addSpark(kind, x, y, size, life = 14) {
  game.sparks.push({ kind, x: x * CONFIG.TILE + 8, y: y * CONFIG.TILE + 8, size, t: life, max: life });
}

// ---------- Início / níveis ----------
function newGame() {
  const s = CONFIG.PLAYER_START;
  game.player = { x: 0, y: 0, hp: s.hp, maxHp: s.hp, atk: s.atk, def: s.def, kills: 0 };
  game.popups = []; game.sparks = []; game.turn = 0;
  loadLevel(0);
  game.state = 'play';
  if (!music.audio) startMusic();
}

function confirmMenu() {
  if (game.state === 'win') game.state = 'title';
  else { playSound('ok'); newGame(); }
}

function loadLevel(index) {
  const level = LEVELS[index], p = game.player;
  game.levelIndex = index;
  game.grid = []; game.enemies = [];
  game.message = level.hint;

  level.map.forEach((row, y) => game.grid.push([...row].map((ch, x) => {
    if (ch === '@') { p.x = x; p.y = y; return '.'; }
    if (ENEMY_TYPES[ch]) { spawnEnemy(ch, x, y); return '.'; }
    return ch;
  })));

  // Células alcançáveis a partir do jogador (para sortear spawns sem bloquear nada).
  const seen = { [p.x + ',' + p.y]: 1 }, queue = [[p.x, p.y]], cells = [];
  while (queue.length) {
    const [x, y] = queue.shift();
    cells.push([x, y]);
    for (const [dx, dy] of DIRS) {
      const key = (x + dx) + ',' + (y + dy);
      if (!seen[key] && !isWall(game.grid[y + dy][x + dx])) { seen[key] = 1; queue.push([x + dx, y + dy]); }
    }
  }
  const used = {};
  const pickCell = minDist => {
    const cand = cells.filter(([x, y]) =>
      Math.abs(x - p.x) + Math.abs(y - p.y) >= minDist &&
      game.grid[y][x] === '.' && !used[x + ',' + y] && !enemyAt(x, y));
    const [x, y] = cand[Math.random() * cand.length | 0];
    used[x + ',' + y] = 1;
    return [x, y];
  };
  for (const type in level.enemies)
    for (let n = 0; n < level.enemies[type]; n++) {
      const [x, y] = pickCell(BALANCE.SPAWN_MIN_DIST_ENEMY);
      spawnEnemy(type, x, y);
    }
  for (const item in level.items)
    for (let n = 0; n < level.items[item]; n++) {
      const [x, y] = pickCell(BALANCE.SPAWN_MIN_DIST_ITEM);
      game.grid[y][x] = item;
    }
}

function spawnEnemy(type, x, y) {
  const t = ENEMY_TYPES[type];
  game.enemies.push({ ...t, x, y, maxHp: t.hp });
}

// ---------- Recompensas ----------
function chooseUpgrade(n) {
  game.options[n].apply(game.player);
  playSound('coin');
  game.state = 'play';
  game.message = game.options[n].name;
}

// ---------- Combate ----------
function hurtPlayer(dmg, sparkKind) {
  const p = game.player;
  p.hp -= dmg;
  addPopup(p.x, p.y, '-' + dmg, '#ff5555');
  playSound('hurt', 0.6);
  game.shake = dmg > 5 ? 14 : 8;
  addSpark(sparkKind, p.x, p.y, sparkKind === 'magic_03' ? 60 : 28, 18);
  if (p.hp <= 0) { p.hp = 0; game.state = 'over'; playSound('lose', 0.7); }
}

// Linha reta sem parede entre inimigo e jogador (para tiros do diabrete).
function hasClearShot(e) {
  const p = game.player, sx = Math.sign(p.x - e.x), sy = Math.sign(p.y - e.y);
  for (let x = e.x + sx, y = e.y + sy; x !== p.x || y !== p.y; x += sx, y += sy)
    if (isWall(game.grid[y][x])) return false;
  return true;
}

// BFS: primeiro passo do caminho mais curto até ficar adjacente ao jogador.
function stepToward(e) {
  const p = game.player;
  const queue = [[e.x, e.y, null]], seen = { [e.x + ',' + e.y]: 1 };
  while (queue.length) {
    const [x, y, first] = queue.shift();
    if (Math.abs(x - p.x) + Math.abs(y - p.y) === 1) return first;
    for (const [dx, dy] of DIRS) {
      const nx = x + dx, ny = y + dy, key = nx + ',' + ny;
      if (seen[key] || !isFree(nx, ny)) continue;
      seen[key] = 1;
      queue.push([nx, ny, first || [dx, dy]]);
    }
  }
  return null;
}

function enemyTurn() {
  const p = game.player;
  game.turn++;
  for (const e of game.enemies) {
    const dx = p.x - e.x, dy = p.y - e.y, dist = Math.abs(dx) + Math.abs(dy);

    if (e.boss && dist <= BALANCE.BOSS_AGGRO_RANGE) {
      if (e.warn) {   // ataque carregado no turno anterior: dispara
        e.warn = false;
        if (dist <= BALANCE.BOSS_BLAST_RADIUS) {
          hurtPlayer(Math.max(1, BALANCE.BOSS_BLAST_DMG - p.def), 'magic_03');
          if (game.state !== 'play') return;
        }
        continue;
      }
      if (game.turn % BALANCE.BOSS_CHARGE_EVERY === 0) {
        e.warn = true;
        game.message = 'O Lorde Demonio carrega um ataque! Saia da area vermelha!';
        playSound('door', 0.5);
        continue;
      }
    }

    if (dist === 1) {
      hurtPlayer(Math.max(1, e.atk - p.def), 'scratch_01');
      if (game.state !== 'play') return;
      continue;
    }
    if (e.ranged && dist <= BALANCE.IMP_SHOOT_RANGE && (dx === 0 || dy === 0) && hasClearShot(e)) {
      hurtPlayer(Math.max(1, e.atk - p.def), 'magic_01');
      if (game.state !== 'play') return;
      game.message = 'O Diabrete atira!';
      continue;
    }
    if (dist > BALANCE.CHASE_RANGE || (e.slow && game.turn % 2)) continue;

    let move = null;
    if (e.ranged && dist <= 2) {
      // diabrete tenta se afastar do jogador
      const distAfter = ([a, b]) => Math.abs(p.x - e.x - a) + Math.abs(p.y - e.y - b);
      move = DIRS.filter(([a, b]) => isFree(e.x + a, e.y + b)).sort((m, n) => distAfter(n) - distAfter(m))[0];
    } else if (e.wild && Math.random() < BALANCE.WILD_MOVE_CHANCE) {
      move = [[0, 1], [0, -1], [1, 0], [-1, 0]].sort(() => Math.random() - 0.5)
        .find(([a, b]) => isFree(e.x + a, e.y + b));
    } else {
      move = stepToward(e);
    }
    if (move) { e.x += move[0]; e.y += move[1]; }
  }
}

function playerAct(dx, dy) {
  if (game.state !== 'play') return;
  const p = game.player, nx = p.x + dx, ny = p.y + dy;

  if (dx || dy) {
    const target = enemyAt(nx, ny);
    if (target) {
      const dmg = p.atk + (Math.random() < BALANCE.CRIT_CHANCE ? 1 : 0);
      target.hp -= dmg;
      addPopup(target.x, target.y, '-' + dmg, '#ffd24a');
      playSound('hit', 0.6);
      addSpark('slash_0' + (1 + Math.random() * 4 | 0), target.x, target.y, 30);
      game.shake = 3;
      if (target.hp <= 0) {
        game.enemies.splice(game.enemies.indexOf(target), 1);
        p.kills++;
        playSound('die', 0.6);
        game.message = target.name + ' derrotado!';
        if (target.boss) {
          game.state = 'win';
          if (!game.best || game.turn < game.best) {
            game.best = game.turn;
            try { localStorage.setItem(CONFIG.BEST_KEY, game.turn); } catch (e) {}
          }
          playSound('win', 0.8);
          music.audio?.pause();
          return;
        }
      }
    } else if (isWall(game.grid[ny][nx])) {
      playSound('no', 0.3);
      return;   // bater na parede não gasta turno
    } else {
      p.x = nx; p.y = ny;
      playSound('step', 0.3);
      const ch = game.grid[ny][nx];
      if (ch === 'h') { p.hp = Math.min(p.maxHp, p.hp + BALANCE.POTION_HEAL); game.message = 'Pocao! +10 de vida.'; addPopup(nx, ny, '+' + BALANCE.POTION_HEAL, '#6cff8a'); }
      if (ch === 'w') { p.atk += BALANCE.SWORD_ATK; game.message = 'Espada nova! Ataque +2.'; }
      if (ch === 'd') { p.def += BALANCE.ARMOR_DEF; game.message = 'Armadura! Defesa +1.'; }
      if ('hwd'.includes(ch)) { game.grid[ny][nx] = '.'; playSound('coin', 0.6); }
      if (ch === '>') {
        playSound('ok');
        p.hp = Math.min(p.maxHp, p.hp + BALANCE.STAIRS_HEAL);
        loadLevel(game.levelIndex + 1);
        return;
      }
    }
  }

  enemyTurn();

  // Sala limpa: portas viram escadas e o jogador escolhe uma recompensa.
  if (game.state === 'play' && !game.enemies.length) {
    let opened = false;
    for (const row of game.grid)
      for (let x = 0; x < CONFIG.MAP_W; x++)
        if (row[x] === 'D') { row[x] = '>'; opened = true; }
    if (opened) {
      playSound('door');
      game.message = 'A porta se abriu! Escolha uma recompensa.';
      game.options = [...UPGRADES].sort(() => Math.random() - 0.5).slice(0, 3);
      game.state = 'pick';
    }
  }
}
