// Bootstrap: carrega assets, liga entrada e inicia o loop.
function loop() {
  render();
  requestAnimationFrame(loop);
}

async function main() {
  setupCanvas();
  drawLoading(0);
  try {
    await loadAllAssets(drawLoading);
    await document.fonts.load('10px "' + CONFIG.FONT + '"').catch(() => {});
  } catch (err) {
    console.error(err);
    drawLoading(0, err.message);
    return;
  }
  initInput(canvas);
  loop();
}

main();
