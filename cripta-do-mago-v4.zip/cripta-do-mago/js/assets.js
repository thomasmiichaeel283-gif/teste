// Carregamento de imagens e áudio.
const IMAGES = {};   // sprites
const FX_IMAGES = {};
const SFX = {};      // nome -> [Audio]
const BGM_FILES = [];

const music = { audio: null, enabled: true };

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Falha ao carregar: ' + src));
    img.src = src;
  });
}

async function loadAllAssets(onProgress) {
  const jobs = [];
  for (const n of MANIFEST.sprites) jobs.push([n, 'assets/sprites/' + n + '.png', IMAGES]);
  for (const n of MANIFEST.fx) jobs.push([n, 'assets/fx/' + n + '.png', FX_IMAGES]);

  let done = 0;
  await Promise.all(jobs.map(async ([name, src, target]) => {
    target[name] = await loadImage(src);
    onProgress?.(++done / jobs.length);
  }));

  // Áudio: criado sem bloquear o carregamento (o navegador baixa em segundo plano).
  for (const [name, count] of Object.entries(MANIFEST.sfx)) {
    SFX[name] = [];
    for (let i = 1; i <= count; i++) SFX[name].push(new Audio(`assets/sfx/${name}_${i}.ogg`));
  }
  for (let i = 1; i <= MANIFEST.music; i++) BGM_FILES.push(`assets/music/bgm_${i}.ogg`);
}

function playSound(name, volume = 0.5) {
  const variants = SFX[name];
  if (!variants) return;
  const a = variants[Math.random() * variants.length | 0].cloneNode();
  a.volume = volume;
  a.play().catch(() => {});
}

function startMusic() {
  if (!music.enabled) return;
  music.audio = new Audio(BGM_FILES[Math.random() * BGM_FILES.length | 0]);
  music.audio.volume = 0.22;
  music.audio.onended = () => setTimeout(startMusic, 3000);
  music.audio.play().catch(() => {});
}

function toggleMusic(isPlaying) {
  music.enabled = !music.enabled;
  if (music.enabled) { if (isPlaying) startMusic(); }
  else music.audio?.pause();
}
