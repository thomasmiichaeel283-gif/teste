// Constantes e dados do jogo (nada de lógica aqui).
const CONFIG = {
  TILE: 16,        // tamanho do tile em pixels lógicos
  MAP_W: 20,       // largura do mapa em tiles
  MAP_H: 12,       // altura do mapa em tiles
  HUD_ROWS: 3,     // linhas de tile reservadas ao HUD, abaixo do mapa
  ZOOM: 3,         // escala do canvas
  FONT: 'Kenney Future',
  PLAYER_START: { hp: 24, atk: 3, def: 0 },
  BEST_KEY: 'cripta_best',
};
CONFIG.VIEW_W = CONFIG.MAP_W * CONFIG.TILE;
CONFIG.VIEW_H = (CONFIG.MAP_H + CONFIG.HUD_ROWS) * CONFIG.TILE;

// Tipos de inimigo. Flags: slow (anda a cada 2 turnos), wild (40% de mover aleatório),
// ranged (atira em linha reta), boss.
const ENEMY_TYPES = {
  s: { sprite: 'monster_elemental_goo_small', hp: 3,  atk: 2, name: 'Slime', slow: true },
  b: { sprite: 'monster_bat',                 hp: 3,  atk: 2, name: 'Morcego', wild: true },
  p: { sprite: 'monster_skelet',              hp: 6,  atk: 3, name: 'Esqueleto' },
  g: { sprite: 'monster_zombie_green',        hp: 6,  atk: 3, name: 'Zumbi' },
  c: { sprite: 'monster_chort',               hp: 8,  atk: 3, name: 'Chort' },
  i: { sprite: 'monster_imp',                 hp: 4,  atk: 3, name: 'Diabrete', ranged: true },
  B: { sprite: 'monster_demon',               hp: 30, atk: 4, name: 'Lorde Demonio', boss: true },
};

// Legenda dos mapas: # parede, . chão, @ jogador, D porta, B boss (letras de ENEMY_TYPES = inimigo fixo).
// `enemies`: quantidade sorteada por tipo. `items`: h poção, w espada, d armadura.
const LEVELS = [
  { name: 'Entrada da Cripta', hint: 'Mate os monstros para abrir a porta.',
    enemies: { s: 3 }, items: { h: 2, w: 1 }, map: [
    '####################',
    '#@...#.............#',
    '#....#.............#',
    '#....#.............#',
    '#..................#',
    '#....#.............#',
    '##.###.....##.##...#',
    '#....#.....#...#...#',
    '#....#.....#...#...#',
    '#....#.....#####..D#',
    '#....#.............#',
    '####################'] },
  { name: 'Catacumbas', hint: 'Esqueletos e morcegos. Ache a armadura!',
    enemies: { b: 2, p: 2, g: 1, s: 1 }, items: { h: 2, d: 1 }, map: [
    '####################',
    '#@.....#...........#',
    '#......#...........#',
    '#..###.#..#######..#',
    '#..#.#....#.....#..#',
    '#..#.#.##.#.....#..#',
    '#..#.#.##.###.###..#',
    '#..................#',
    '#..###.............#',
    '#..###.........#..D#',
    '#..###.............#',
    '####################'] },
  { name: 'Salao do Demonio', hint: 'O Lorde Demonio! Fuja da area vermelha!',
    enemies: { c: 2, g: 1, b: 1, i: 1 }, items: { h: 3 }, map: [
    '####################',
    '#@.................#',
    '#..##.........##...#',
    '#..................#',
    '#.......####.......#',
    '#.......#..B.......#',
    '#.......####.......#',
    '#..................#',
    '#..##.........##...#',
    '#..................#',
    '#..................#',
    '####################'] },
];

// Recompensas ao limpar uma sala.
const UPGRADES = [
  { name: 'Forca: +1 ataque',            apply: p => { p.atk++; } },
  { name: 'Pele de pedra: +1 defesa',    apply: p => { p.def++; } },
  { name: 'Vitalidade: +6 vida maxima',  apply: p => { p.maxHp += 6; p.hp += 6; } },
  { name: 'Cura total agora',            apply: p => { p.hp = p.maxHp; } },
];

// Valores de balanceamento espalhados antes como números mágicos.
const BALANCE = {
  POTION_HEAL: 10,
  SWORD_ATK: 2,
  ARMOR_DEF: 1,
  STAIRS_HEAL: 6,
  CRIT_CHANCE: 0.3,
  BOSS_AGGRO_RANGE: 7,
  BOSS_CHARGE_EVERY: 3,   // turnos
  BOSS_BLAST_DMG: 7,
  BOSS_BLAST_RADIUS: 2,
  CHASE_RANGE: 9,
  IMP_SHOOT_RANGE: 5,
  WILD_MOVE_CHANCE: 0.4,
  SPAWN_MIN_DIST_ENEMY: 6,
  SPAWN_MIN_DIST_ITEM: 3,
};
