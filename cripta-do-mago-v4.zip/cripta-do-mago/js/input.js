// Teclado e toque. Traduz entrada em chamadas de ação do jogo.
const KEY_TO_DIR = {
  arrowup: [0, -1], w: [0, -1],
  arrowdown: [0, 1], s: [0, 1],
  arrowleft: [-1, 0], a: [-1, 0],
  arrowright: [1, 0], d: [1, 0],
  ' ': [0, 0],   // esperar um turno
};

function initInput(canvas) {
  addEventListener('keydown', e => {
    const key = e.key.toLowerCase();
    if (key === 'm') { toggleMusic(game.state === 'play'); return; }

    if (game.state === 'pick') {
      if (key >= '1' && key <= '3') chooseUpgrade(+key - 1);
      return;
    }
    if (game.state !== 'play') {
      if (key === 'enter' || key === ' ') confirmMenu();
      return;
    }
    const dir = KEY_TO_DIR[key];
    if (dir) { e.preventDefault(); playerAct(...dir); }
  });

  canvas.addEventListener('pointerdown', ev => {
    const r = canvas.getBoundingClientRect();
    const x = (ev.clientX - r.left) / r.width * CONFIG.MAP_W;
    const y = (ev.clientY - r.top) / r.height * (CONFIG.MAP_H + CONFIG.HUD_ROWS);

    if (game.state === 'pick') { chooseUpgrade(Math.min(2, x / CONFIG.MAP_W * 3 | 0)); return; }
    if (game.state !== 'play') { confirmMenu(); return; }

    const dx = x - game.player.x - 0.5, dy = y - game.player.y - 0.5;
    if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5) playerAct(0, 0);
    else if (Math.abs(dx) > Math.abs(dy)) playerAct(Math.sign(dx), 0);
    else playerAct(0, Math.sign(dy));
  });
}
