# Créditos
- Fonte: Kenney Future — Kenney (kenney.nl), CC0.
- Sprites 16x16 (herói, monstros, paredes, itens): estilo/nomes do 0x72 DungeonTileset, CC0 (confirme a origem exata de cada arquivo).
- Áudio (sfx/música): packs do Kenney (CC0) — confirme a origem exata de cada arquivo.
CC0 não exige atribuição, mas é bom manter este arquivo.
